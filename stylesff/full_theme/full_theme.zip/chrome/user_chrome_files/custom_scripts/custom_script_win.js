// Этот скрипт работает в главном окне браузера если включено в настройках
// Чтобы раскомментировать нужный код удалите  /*disabled
/*disabled
var {classes: Cc, interfaces: Ci, utils: Cu} = Components;  /* */

// Вы должны использовать событие "load" если хотите дождаться загрузки всех ресурсов
window.addEventListener("load", function load() {
    window.removeEventListener("load", load, false);
    var unloadtListeners = [];
    /** ******** Код для Special Widgets --> **********/
    /*disabled
    var specialwidgets = {
        _separator: null,
        _spacer: null,
        _spring: null,
        _timer: null,
        get Customizable() {
            delete this.Customizable;
            if ("createSpecialWidget" in window.CustomizableUI)
                return this.Customizable = window.CustomizableUI;
            var scope = null;
            try {
                scope = Components.utils.import("resource:///modules/CustomizableUI.jsm", {}).CustomizableUIInternal;
            } catch (e) { }
            return this.Customizable = scope;
        },
        constructor: function() {
            if (!("CustomizableUI" in window) || !("gCustomizeMode" in window))
                return;
            unloadtListeners.push(this.destructor);
            window.addEventListener("customizationready", this, false);
        },
        destructor: function() {
            window.removeEventListener("customizationready", this, false);
        },
        handleEvent: function(event) {
            if (event.type == "customizationchange") {
                clearTimeout(this._timer);
                this._timer = setTimeout(() => {
                    this.createSpecialWidgets();
                }, 1000);
            } else if (event.type == "customizationready") {
                if (this.Customizable !== null) {
                    this.createSpecialWidgets();
                    window.addEventListener("customizationchange", this, false);
                    window.addEventListener("customizationending", this, false);
                }
            } else if (event.type == "customizationending") {
                window.removeEventListener("customizationchange", this, false);
                window.removeEventListener("customizationending", this, false);
            }
        },
        createSpecialWidgets: function(event) {
            try {
                var fragment = document.createDocumentFragment();
                if (!this._spring || this.findSpecialWidgets(this._spring, "spring")) {
                    var spring = this.Customizable.createSpecialWidget("spring", document);
                    if (this._spring != null || (!this._spring && this.findSpecialWidgets(spring.id, "spring"))) {
                        spring.setAttribute("label", "Растягивающийся интервал");
                        fragment.appendChild(gCustomizeMode.wrapToolbarItem(spring, "palette"));
                    }
                    this._spring = spring.id;
                }
                if (!this._spacer || this.findSpecialWidgets(this._spacer, "spacer")) {
                    var spacer = this.Customizable.createSpecialWidget("spacer", document);
                    if (this._spacer != null || (!this._spacer && this.findSpecialWidgets(spacer.id, "spacer"))) {
                        spacer.setAttribute("label", "Интервал");
                        fragment.appendChild(gCustomizeMode.wrapToolbarItem(spacer, "palette"));
                    }
                    this._spacer = spacer.id;
                }
                if (!this._separator || this.findSpecialWidgets(this._separator, "separator")) {
                    var separator = this.Customizable.createSpecialWidget("separator", document);
                    if (this._separator != null || (!this._separator && this.findSpecialWidgets(separator.id, "separator"))) {
                        separator.setAttribute("label", "Разделитель");
                        fragment.appendChild(gCustomizeMode.wrapToolbarItem(separator, "palette"));
                    }
                    this._separator = separator.id;
                }
                gCustomizeMode.visiblePalette.appendChild(fragment);
            } catch (e) {}
        },
        findSpecialWidgets: function(eltid, string) {
            if (!eltid) return false;
            try {
                if (!gCustomizeMode.visiblePalette.querySelector("toolbar" + string + "[id^='" + eltid.split(string)[0] + string + "']"))
                    return true;
                return false;
            } catch (e) {
                return false;
            }
        }
    };
    specialwidgets.constructor();
    /*  */ /** <-- Special Widgets */

    /** ******** Код для Auto Hide Sidebar --> **********/
    var sidebar = null;
    var autoHideSidebar = {
        constructor: function() {
            sidebar = document.querySelector("#sidebar-box");
            if(!sidebar)
                return;
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.addEventListener(type, this, false);
            });
            unloadtListeners.push(this.destructor);
        },
        destructor: function() {
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.removeEventListener(type, this, false);
            });
        },
        handleEvent: function(event) {
            this[event.type](event);
        },
        dragenter: function() {
            if (!sidebar.hasAttribute("sidebardrag"))
            sidebar.setAttribute("sidebardrag", "true");
        },
        drop: function() {
            if (sidebar.hasAttribute("sidebardrag"))
            sidebar.removeAttribute("sidebardrag");
        },
        dragexit: function(event) {
            var boxObj = sidebar.getBoundingClientRect(), boxScrn = !sidebar.boxObject ? sidebar : sidebar.boxObject;
            if ((!event.relatedTarget || event.screenY <= (boxScrn.screenY + 5) || event.screenY  >= (boxScrn.screenY + boxObj.height - 5)
                || event.screenX <= (boxScrn.screenX + 5) || event.screenX >= (boxScrn.screenX + boxObj.width - 5))
                && sidebar.hasAttribute("sidebardrag"))
                sidebar.removeAttribute("sidebardrag");
        }
    };
    autoHideSidebar.constructor();
    /*  */ /** <-- Auto Hide Sidebar */

    if (unloadtListeners.length < 1) return;
    window.addEventListener("unload", function unload() {
        window.removeEventListener("unload", unload, false);
        unloadtListeners.forEach((func) => {
            try {
                func();
            } catch (e) {}
        });
        unloadtListeners = [];
    }, false);
}, false);

// Этот скрипт работает в главном окне браузера если включено в настройках

var ucf_custom_script_win = {
    initialized: false,
    unloadlisteners: [],
    load: function() {
        if (this.initialized)
            return;
        this.initialized = true;
        // this.specialwidgets.constructor(); // <-- Special Widgets
        this.autohidesidebar.constructor(); // <-- Auto Hide Sidebar
        /* ************************************************ */

        // Здесь может быть ваш код который сработает по событию "load" не раньше
        this.contextproxy.constructor();
        /* ************************************************ */
        if (this.unloadlisteners.length < 1)
            return;
        window.addEventListener("unload", this, false);
    },
    handleEvent: function(event) {
        this[event.type](event);
    },
    unload: function() {
        window.removeEventListener("unload", this, false);
        this.unloadlisteners.forEach((str) => {
            try {
                this[str].destructor();
            } catch (e) {}
        });
    },
    specialwidgets: {
        _timer: null,
        get Customizable() {
            delete this.Customizable;
            if ("createSpecialWidget" in CustomizableUI)
                return this.Customizable = CustomizableUI;
            var scope = null;
            try {
                scope = Cu.import("resource:///modules/CustomizableUI.jsm", {}).CustomizableUIInternal;
            } catch (e) { }
            return this.Customizable = scope;
        },
        constructor: function() {
            if (!("CustomizableUI" in window) || !("gCustomizeMode" in window))
                return;
            ucf_custom_script_win.unloadlisteners.push("specialwidgets");
            window.addEventListener("customizationready", this, false);
        },
        destructor: function() {
            window.removeEventListener("customizationready", this, false);
        },
        handleEvent: function(event) {
            this[event.type](event);
        },
        customizationchange: function() {
            clearTimeout(this._timer);
            this._timer = setTimeout(() => {
                this.createSpecialWidgets();
            }, 1000);
        },
        customizationready: function() {
            if (!this.Customizable)
                return;
            this.createSpecialWidgets();
            window.addEventListener("customizationchange", this, false);
            window.addEventListener("customizationending", this, false);
        },
        customizationending: function() {
            window.removeEventListener("customizationchange", this, false);
            window.removeEventListener("customizationending", this, false);
        },
        createSpecialWidgets: function() {
            try {
                var fragment = document.createDocumentFragment();
                if (this.findSpecialWidgets("spring")) {
                    var spring = this.Customizable.createSpecialWidget("spring", document);
                    spring.setAttribute("label", "Растягивающийся интервал");
                    fragment.append(gCustomizeMode.wrapToolbarItem(spring, "palette"));
                }
                if (this.findSpecialWidgets("spacer")) {
                    var spacer = this.Customizable.createSpecialWidget("spacer", document);
                    spacer.setAttribute("label", "Интервал");
                    fragment.append(gCustomizeMode.wrapToolbarItem(spacer, "palette"));
                }
                if (this.findSpecialWidgets("separator")) {
                    var separator = this.Customizable.createSpecialWidget("separator", document);
                    separator.setAttribute("label", "Разделитель");
                    fragment.append(gCustomizeMode.wrapToolbarItem(separator, "palette"));
                }
                gCustomizeMode.visiblePalette.append(fragment);
            } catch (e) {}
        },
        findSpecialWidgets: function(string) {
            try {
                if (!gCustomizeMode.visiblePalette.querySelector(`toolbar${string}[id^="customizableui-special-${string}"]`))
                    return true;
            } catch (e) {}
            return false;
        }
    },
    autohidesidebar: {
        sidebar: null,
        constructor: function() {
            var sidebar = this.sidebar = document.querySelector("#sidebar-box");
            if(!sidebar)
                return;
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.addEventListener(type, this, false);
            });
            ucf_custom_script_win.unloadlisteners.push("autohidesidebar");
        },
        destructor: function() {
            var sidebar = this.sidebar;
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.removeEventListener(type, this, false);
            });
        },
        handleEvent: function(event) {
            this[event.type](event);
        },
        dragenter: function() {
            if (!this.sidebar.hasAttribute("sidebardrag"))
            this.sidebar.setAttribute("sidebardrag", "true");
        },
        drop: function() {
            if (this.sidebar.hasAttribute("sidebardrag"))
            this.sidebar.removeAttribute("sidebardrag");
        },
        dragexit: function(event) {
            var sidebar = this.sidebar;
            var boxObj = sidebar.getBoundingClientRect(), boxScrn = !sidebar.boxObject ? sidebar : sidebar.boxObject;
            if ((!event.relatedTarget || event.screenY <= (boxScrn.screenY + 5) || event.screenY  >= (boxScrn.screenY + boxObj.height - 5)
                || event.screenX <= (boxScrn.screenX + 5) || event.screenX >= (boxScrn.screenX + boxObj.width - 5))
                && sidebar.hasAttribute("sidebardrag"))
                sidebar.removeAttribute("sidebardrag");
        }
    },
    contextproxy: {
        img: "data:image/svg+xml;charset=utf-8,<svg xmlns='http://www.w3.org/2000/svg' height='16' width='16' viewBox='0 0 48 48'><g><rect x='0' y='0' width='48' height='48' rx='3' ry='3' style='fill:rgb(209, 8, 3);'/><path style='opacity:0.25;fill:black;' d='M 16.8,17.6 23.1,23.9 8,26 6.4,32.2 11.4,37.2 3.7,44.8 6.9,48 45,48 C 46.7,48 48,46.7 48,45 V 20 L 31.4,3.4'/><path style='fill:white;' d='M 17.4,3 C 16.7,3 16.2,3.82 16.2,4.91 V 15.9 C 16.2,17 16.7,17.8 17.4,17.8 H 30.6 C 31.3,17.8 31.8,17 31.8,15.9 V 4.91 C 31.8,3.82 31.3,3 30.6,3 H 17.4 M 22.4,20.5 V 23.7 H 6.41 V 32.2 H 9.35 V 28.2 H 22.4 V 32.4 H 25.5 V 28.2 H 38.5 V 32.4 H 41.5 V 23.7 H 25.5 V 20.5 H 22.4 M 4.23,35.1 C 3.55,35.1 3,35.9 3,37.1 V 43 C 3,44.1 3.55,45 4.23,45 H 12.1 C 12.8,45 13.3,44.1 13.3,43 V 37.1 C 13.3,35.9 12.8,35.1 12.1,35.1 H 4.23 M 19.9,35.1 C 19.2,35.1 18.7,35.9 18.7,37.1 V 43 C 18.7,44.1 19.2,45 19.9,45 H 27.8 C 28.5,45 29,44.1 29,43 V 37.1 C 29,35.9 28.5,35.1 27.8,35.1 H 19.9 M 35.9,35.1 C 35.2,35.1 34.7,35.9 34.7,37.1 V 43 C 34.7,44.1 35.2,45 35.9,45 H 43.7 C 44.4,45 45,44.1 45,43 V 37.1 C 45,35.9 44.4,35.1 43.7,35.1 H 35.9' /></g></svg>",
        constructor: function() {
            var contextMenu = this.contextMenu = document.querySelector("#contentAreaContextMenu");
            if (!contextMenu)
                return;
            contextMenu.addEventListener("popupshowing", this, false);
            ucf_custom_script_win.unloadlisteners.push("contextproxy");
        },
        destructor: function() {
            this.contextMenu.removeEventListener("popupshowing", this, false);
        },
        handleEvent(e) {
            if (!gContextMenu.isContentSelected)
                return;
            var menuitem = document.createXULElement("menuitem");
            menuitem.setAttribute("label", "Добавить прокси");
            menuitem.className = "menuitem-iconic";
            menuitem.setAttribute("image", this.img);
            menuitem.onclick = this.addNewProxy.bind(this);
            (e.target.querySelector("menuseparator#context-sep-selectall") || e.target.lastElementChild).after(menuitem);
            this.handleEvent = () => menuitem.hidden = !gContextMenu.isContentSelected;
        },
        addNewProxy(e) {
            var sel = gContextMenu.selectionInfo.fullText;
            sel = sel.trim().replace(/\s+/g, ":");
            var prefs = Services.prefs, lab;
            if (sel.length < 6 && isFinite(sel)) {
                lab = "порт", sel = +sel;
                prefs.setIntPref("network.proxy.http_port", sel);
                prefs.setIntPref("network.proxy.ssl_port", sel);
                prefs.setIntPref("network.proxy.ftp_port", sel);
            } else if (sel.length > 5 && !(/:/.test(sel)) && sel.split(".").length == 4) {
                lab = "адрес";
                prefs.setStringPref("network.proxy.http", sel);
                prefs.setStringPref("network.proxy.ssl", sel);
                prefs.setStringPref("network.proxy.ftp", sel);
            } else if (sel.length > 5 && /:/.test(sel) && sel.split(":").length == 2 && sel.split(".").length == 4) {
                lab = "адрес и порт";
                var arr = sel.split(":"), IP = arr[0], port = +arr[1];
                prefs.setIntPref("network.proxy.http_port", port);
                prefs.setStringPref("network.proxy.http", IP);
                prefs.setIntPref("network.proxy.ssl_port", port);
                prefs.setStringPref("network.proxy.ssl", IP);
                prefs.setIntPref("network.proxy.ftp_port", port);
                prefs.setStringPref("network.proxy.ftp", IP);
            } else
               return;
            if (prefs.getIntPref("network.proxy.type") != 1)
               prefs.setIntPref("network.proxy.type", 1);
            var mainPopupSet = document.querySelector("#mainPopupSet");
            var tooltip = document.createXULElement("tooltip");
            tooltip.style.cssText = "font-size: 1.2em !important; -moz-box-orient: horizontal; text-align: center; pointer-events: none; -moz-box-align: center !important;";
            tooltip.label = " Установлен " + lab + " прокси: " + sel;
            var image = document.createXULElement("image");
            image.setAttribute("src", this.img);
            tooltip.firstElementChild.before(image);
            mainPopupSet.append(tooltip);
            tooltip.openPopup(e.target.parentNode, "before_start");
            setTimeout(() => mainPopupSet.removeChild(tooltip), 3000);
        }
    }
};

if (window.document.readyState != "complete") {
    window.addEventListener("load", function load() {
        window.removeEventListener("load", load, false);
        ucf_custom_script_win.load();
    }, false);
} else
    ucf_custom_script_win.load();

try {
    (function() {
        if (AppConstants.platform == "win" && (window.matchMedia("(-moz-os-version: windows-win8)").matches || window.matchMedia("(-moz-os-version: windows-win7)").matches)) {
            eval(`TabsInTitlebar._update = ${TabsInTitlebar._update.toString()
                .replace(/setAttribute\s*\(\s*"\s*chromemargin\s*"\s*,\s*"\s*0\s*,\s*2\s*,\s*2\s*,\s*2\s*"\s*\)/, 'setAttribute("chromemargin", "0,0,0,0")')
                .replace(/^_update/, "function _update")}`);
            if (TabsInTitlebar.enabled)
                document.documentElement.setAttribute("chromemargin", "0,0,0,0");
        }
    })();
} catch(e) {}

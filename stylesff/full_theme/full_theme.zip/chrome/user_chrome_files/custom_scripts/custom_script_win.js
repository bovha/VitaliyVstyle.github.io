// Этот скрипт работает в главном окне браузера если включено в настройках

var ucf_custom_script_win = {
    initialized: false,
    unloadlisteners: [],
    load: function() {
        if (this.initialized)
            return;
        this.initialized = true;
        // this.specialwidgets.constructor(); // <-- Special Widgets
        this.autohidesidebar.constructor(); // <-- Auto Hide Sidebar
        /* ************************************************ */

        // Здесь может быть ваш код который сработает по событию "load" не раньше

        /* ************************************************ */
        if (this.unloadlisteners.length < 1)
            return;
        window.addEventListener("unload", this, false);
    },
    handleEvent: function(event) {
        this[event.type](event);
    },
    unload: function() {
        window.removeEventListener("unload", this, false);
        this.unloadlisteners.forEach((str) => {
            try {
                this[str].destructor();
            } catch (e) {}
        });
    },
    specialwidgets: {
        _timer: null,
        get Customizable() {
            delete this.Customizable;
            if ("createSpecialWidget" in CustomizableUI)
                return this.Customizable = CustomizableUI;
            var scope = null;
            try {
                scope = Components.utils.import("resource:///modules/CustomizableUI.jsm", {}).CustomizableUIInternal;
            } catch (e) { }
            return this.Customizable = scope;
        },
        constructor: function() {
            if (!("CustomizableUI" in window) || !("gCustomizeMode" in window))
                return;
            ucf_custom_script_win.unloadlisteners.push("specialwidgets");
            window.addEventListener("customizationready", this, false);
        },
        destructor: function() {
            window.removeEventListener("customizationready", this, false);
        },
        handleEvent: function(event) {
            this[event.type](event);
        },
        customizationchange: function() {
            clearTimeout(this._timer);
            this._timer = setTimeout(() => {
                this.createSpecialWidgets();
            }, 1000);
        },
        customizationready: function() {
            if (!this.Customizable)
                return;
            this.createSpecialWidgets();
            window.addEventListener("customizationchange", this, false);
            window.addEventListener("customizationending", this, false);
        },
        customizationending: function() {
            window.removeEventListener("customizationchange", this, false);
            window.removeEventListener("customizationending", this, false);
        },
        createSpecialWidgets: function() {
            try {
                var fragment = document.createDocumentFragment();
                if (this.findSpecialWidgets("spring")) {
                    var spring = this.Customizable.createSpecialWidget("spring", document);
                    spring.setAttribute("label", "Растягивающийся интервал");
                    fragment.appendChild(gCustomizeMode.wrapToolbarItem(spring, "palette"));
                }
                if (this.findSpecialWidgets("spacer")) {
                    var spacer = this.Customizable.createSpecialWidget("spacer", document);
                    spacer.setAttribute("label", "Интервал");
                    fragment.appendChild(gCustomizeMode.wrapToolbarItem(spacer, "palette"));
                }
                if (this.findSpecialWidgets("separator")) {
                    var separator = this.Customizable.createSpecialWidget("separator", document);
                    separator.setAttribute("label", "Разделитель");
                    fragment.appendChild(gCustomizeMode.wrapToolbarItem(separator, "palette"));
                }
                gCustomizeMode.visiblePalette.appendChild(fragment);
            } catch (e) {}
        },
        findSpecialWidgets: function(string) {
            try {
                if (!gCustomizeMode.visiblePalette.querySelector(`toolbar${string}[id^="customizableui-special-${string}"]`))
                    return true;
            } catch (e) {}
            return false;
        }
    },
    autohidesidebar: {
        sidebar: null,
        constructor: function() {
            var sidebar = this.sidebar = document.querySelector("#sidebar-box");
            if(!sidebar)
                return;
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.addEventListener(type, this, false);
            });
            ucf_custom_script_win.unloadlisteners.push("autohidesidebar");
        },
        destructor: function() {
            var sidebar = this.sidebar;
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.removeEventListener(type, this, false);
            });
        },
        handleEvent: function(event) {
            this[event.type](event);
        },
        dragenter: function() {
            if (!this.sidebar.hasAttribute("sidebardrag"))
            this.sidebar.setAttribute("sidebardrag", "true");
        },
        drop: function() {
            if (this.sidebar.hasAttribute("sidebardrag"))
            this.sidebar.removeAttribute("sidebardrag");
        },
        dragexit: function(event) {
            var sidebar = this.sidebar;
            var boxObj = sidebar.getBoundingClientRect(), boxScrn = !sidebar.boxObject ? sidebar : sidebar.boxObject;
            if ((!event.relatedTarget || event.screenY <= (boxScrn.screenY + 5) || event.screenY  >= (boxScrn.screenY + boxObj.height - 5)
                || event.screenX <= (boxScrn.screenX + 5) || event.screenX >= (boxScrn.screenX + boxObj.width - 5))
                && sidebar.hasAttribute("sidebardrag"))
                sidebar.removeAttribute("sidebardrag");
        }
    }
};

if (window.document.readyState != "complete") {
    window.addEventListener("load", function load() {
        window.removeEventListener("load", load, false);
        ucf_custom_script_win.load();
    }, false);
} else
    ucf_custom_script_win.load();

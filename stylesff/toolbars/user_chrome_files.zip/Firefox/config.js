//
try {
    (function() {
        var {classes: Cc, interfaces: Ci} = Components;
        var Services = Components.utils.import("resource://gre/modules/Services.jsm", {}).Services;
        var config = {
            SubScript: {},
            observe: function(aSubject, aTopic, aData) {
                if (aTopic == "domwindowopened" && aSubject instanceof Ci.nsIDOMWindow) {
                    aSubject.addEventListener("DOMContentLoaded", function domLoad() {
                        aSubject.removeEventListener("DOMContentLoaded", domLoad, true);
                        var loc = aSubject.location;
                        if (loc && loc.protocol == "chrome:") {
                            try {
                                config.SubScript.user_chrome.loadIntoWindow(aSubject, loc.href);
                            } catch(ex) { }
                        }
                    }, true);
                } else if (aTopic == "profile-after-change") {
                    Services.obs.removeObserver(config, "profile-after-change");
                    var file = Services.dirsvc.get("ProfD", Ci.nsIFile);
                    file.append("user_chrome_files");
                    if (!file.exists() || !file.isDirectory()) {
                        this.removeObs();
                        return;
                    }
                    file.append("user_chrome.manifest");
                    if (!file.exists() || !file.isFile()) {
                        this.removeObs();
                        return;
                    }
                    var reg = Components.manager.QueryInterface(Ci.nsIComponentRegistrar);
                    reg.autoRegister(file);


                    try {
                        Services.scriptloader.loadSubScript("chrome://user_chrome_files/content/user_chrome.js", this.SubScript, "UTF-8");
                    } catch(ex) {
                        this.removeObs();
                    }
                }
            },
            removeObs: function() {
                Services.obs.removeObserver(config, "domwindowopened");
            }
        };
        Services.obs.addObserver(config, "profile-after-change", false);
        Services.obs.addObserver(config, "domwindowopened", false);
    })();
} catch(ex) {
    // Components.utils.reportError(ex);
}

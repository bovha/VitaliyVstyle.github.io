//
try {
    (function(/* Cc, Ci, Cu */) {
        var {Services} = Cu.import("resource://gre/modules/Services.jsm", {});
        var sandbox = Cu.Sandbox(Services.scriptSecurityManager.getSystemPrincipal(), {
            wantComponents: true,
            sandboxName: "user_chrome_files"
        });
        Object.assign(sandbox, {
            Services,
            /* Cc,
            Ci,
            Cu, */
        });
        Cu.evalInSandbox(`
            var config = {
                subScript: {},
                observe: function(aSubject, aTopic, aData) {
                    if (aTopic == "domwindowopened" && aSubject instanceof Ci.nsIDOMWindow) {
                        aSubject.addEventListener("DOMContentLoaded", function domLoad() {
                            aSubject.removeEventListener("DOMContentLoaded", domLoad, true);
                            var loc = aSubject.location;
                            if (loc && loc.protocol == "chrome:") {
                                try {
                                    config.subScript.user_chrome.loadIntoWindow(aSubject, loc.href);
                                } catch(ex) { }
                            }
                        }, true);
                    } else if (aTopic == "profile-after-change") {
                        Services.obs.removeObserver(config, "profile-after-change");
                        var file = Services.dirsvc.get("UChrm", Ci.nsIFile);
                        file.append("user_chrome_files");
                        file.append("user_chrome.manifest");
                        if (!file.exists() || !file.isFile()) {
                            this.removeObs();
                            return;
                        }
                        try {
                            var reg = Components.manager.QueryInterface(Ci.nsIComponentRegistrar);
                            reg.autoRegister(file);
                        } catch(ex) {
                            this.removeObs();
                            return;
                        }

                        try {
                            Services.scriptloader.loadSubScript("chrome://user_chrome_files/content/user_chrome.js", this.subScript, "UTF-8");
                        } catch(ex) {
                            this.removeObs();
                        }
                    }
                },
                removeObs: function() {
                    Services.obs.removeObserver(config, "domwindowopened");
                }
            };
            Services.obs.addObserver(config, "profile-after-change", false);
            Services.obs.addObserver(config, "domwindowopened", false);
        `, sandbox);
    })(/* (this.Cc || Components.classes), (this.Ci || Components.interfaces), (this.Cu || Components.utils) */);
} catch(ex) {
    // Components.utils.reportError(ex);
}

// lockPref("extensions.legacy.enabled", true);
// lockPref("xpinstall.signatures.required", false);
// lockPref("extensions.experiments.enabled", true);
// lockPref("extensions.langpacks.signatures.required", false);

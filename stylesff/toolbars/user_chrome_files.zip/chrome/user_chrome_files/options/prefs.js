if (!window.Cc) window.Cc = Components.classes;
if (!window.Ci) window.Ci = Components.interfaces;
if (!window.Cu) window.Cu = Components.utils;
var {Services} = Cu.import("resource://gre/modules/Services.jsm", {});
var controlArray = [
  "extensions.user_chrome_files.vertical_top_bottom_bar_enable",
  "extensions.user_chrome_files.top_enable",
  "extensions.user_chrome_files.vertical_enable",
  "extensions.user_chrome_files.vertical_autohide"
];

function FillForm(aData, input) {
  var val = GetPref(aData);
  if (input.type == "checkbox") {
    input.checked = val;
    if (controlArray.indexOf(aData) != -1)
      input.parentNode.nextSibling.disabled = !val;
  } else {
    input.value = val;
  }
}

function _FillForm(aSubject, aTopic, aData) {
    var input = document.querySelector("[data-pref='" + aData + "']");
    FillForm(aData, input);
}

function SaveForm(e) {
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    if (i.type == "checkbox") {
      SetPref(pref, i.checked);
    } else {
      SetPref(pref, i.value);
    }
  }
}

function GetPref(name) {
  var type = Services.prefs.getPrefType(name);
  switch (type) {
    case Services.prefs.PREF_STRING:
      return Services.prefs.getCharPref(name);
    case Services.prefs.PREF_INT:
      return Services.prefs.getIntPref(name);
    case Services.prefs.PREF_BOOL:
      return Services.prefs.getBoolPref(name);
  }
}

function SetPref(name, value) {
  var type = Services.prefs.getPrefType(name);
  switch (type) {
    case Services.prefs.PREF_STRING:
      return Services.prefs.setCharPref(name, value);
    case Services.prefs.PREF_INT:
      return Services.prefs.setIntPref(name, value);
    case Services.prefs.PREF_BOOL:
      return Services.prefs.setBoolPref(name, value);
  }
}

function RestoreDefaults() {
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    Services.prefs.clearUserPref(pref);
  }
}

function Restart(nocache = false) {
  var cancelQuit = Cc["@mozilla.org/supports-PRBool;1"].createInstance(Ci.nsISupportsPRBool);
  Services.obs.notifyObservers(cancelQuit, "quit-application-requested", "restart");
  if (cancelQuit.data)
      return false;
  if (nocache)
      Services.appinfo.invalidateCachesOnRestart();
  var restart = Services.startup;
  restart.quit(restart.eAttemptQuit | restart.eRestart);
}

window.addEventListener("load", function onLoad() {
  window.removeEventListener("load", onLoad, true);
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    Services.prefs.addObserver(pref, _FillForm, false);
    i.addEventListener("change", SaveForm, false);
    FillForm(pref, i);
  }
  document.querySelector("#restore").onclick = function() { RestoreDefaults(); };
  document.querySelector("#restart").onclick = function() { Restart(); };
  document.querySelector("#restart_no_cache").onclick = function() { Restart(true); };
}, true);

window.addEventListener("unload", function onUnload() {
  window.removeEventListener("unload", onUnload, true);
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    i.removeEventListener("change", SaveForm, false);
    Services.prefs.removeObserver(pref, _FillForm, false);
  }
}, true);

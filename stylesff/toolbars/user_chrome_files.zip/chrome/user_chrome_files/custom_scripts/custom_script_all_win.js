// Этот скрипт работает во всех окнах браузера если включено в настройках

var ucf_custom_script_all_win = {
    initialized: false,
    unloadlisteners: [],
    load: function() {
        if (this.initialized)
            return;
        this.initialized = true;
        /* ************************************************ */

        // Здесь может быть ваш код который сработает по событию "load" не раньше

        /* ************************************************ */
        if (this.unloadlisteners.length < 1)
            return;
        window.addEventListener("unload", this, false);
    },
    handleEvent: function(event) {
        this[event.type](event);
    },
    unload: function() {
        window.removeEventListener("unload", this, false);
        this.unloadlisteners.forEach((str) => {
            try {
                this[str].destructor();
            } catch (e) {}
        });
    }
};

if (window.document.readyState != "complete") {
    window.addEventListener("load", function load() {
        window.removeEventListener("load", load, false);
        ucf_custom_script_all_win.load();
    }, false);
} else
    ucf_custom_script_all_win.load();

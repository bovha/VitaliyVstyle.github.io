// Этот скрипт работает в главном окне браузера если включено в настройках

var ucf_custom_script_win = {
    initialized: false,
    unloadlisteners: [],
    load: function() {
        if (this.initialized)
            return;
        this.initialized = true;
        // this.specialwidgets.constructor(); // <-- Special Widgets
        // this.autohidesidebar.constructor(); // <-- Auto Hide Sidebar
        /* ************************************************ */

        // Здесь может быть ваш код который сработает по событию "load" не раньше

        /* ************************************************ */
        if (this.unloadlisteners.length < 1)
            return;
        window.addEventListener("unload", this, false);
    },
    handleEvent: function(event) {
        this[event.type](event);
    },
    unload: function() {
        window.removeEventListener("unload", this, false);
        this.unloadlisteners.forEach((str) => {
            try {
                this[str].destructor();
            } catch (e) {}
        });
    },
    specialwidgets: {
        _separator: null,
        _spacer: null,
        _spring: null,
        _timer: null,
        get Customizable() {
            delete this.Customizable;
            if ("createSpecialWidget" in window.CustomizableUI)
                return this.Customizable = window.CustomizableUI;
            var scope = null;
            try {
                scope = Components.utils.import("resource:///modules/CustomizableUI.jsm", {}).CustomizableUIInternal;
            } catch (e) { }
            return this.Customizable = scope;
        },
        constructor: function() {
            if (!("CustomizableUI" in window) || !("gCustomizeMode" in window))
                return;
            ucf_custom_script_win.unloadlisteners.push("specialwidgets");
            window.addEventListener("customizationready", this, false);
        },
        destructor: function() {
            window.removeEventListener("customizationready", this, false);
        },
        handleEvent: function(event) {
            if (event.type == "customizationchange") {
                clearTimeout(this._timer);
                this._timer = setTimeout(() => {
                    this.createSpecialWidgets();
                }, 1000);
            } else if (event.type == "customizationready") {
                if (this.Customizable !== null) {
                    this.createSpecialWidgets();
                    window.addEventListener("customizationchange", this, false);
                    window.addEventListener("customizationending", this, false);
                }
            } else if (event.type == "customizationending") {
                window.removeEventListener("customizationchange", this, false);
                window.removeEventListener("customizationending", this, false);
            }
        },
        createSpecialWidgets: function(event) {
            try {
                var fragment = document.createDocumentFragment();
                if (!this._spring || this.findSpecialWidgets(this._spring, "spring")) {
                    var spring = this.Customizable.createSpecialWidget("spring", document);
                    if (this._spring != null || (!this._spring && this.findSpecialWidgets(spring.id, "spring"))) {
                        spring.setAttribute("label", "Растягивающийся интервал");
                        fragment.appendChild(gCustomizeMode.wrapToolbarItem(spring, "palette"));
                    }
                    this._spring = spring.id;
                }
                if (!this._spacer || this.findSpecialWidgets(this._spacer, "spacer")) {
                    var spacer = this.Customizable.createSpecialWidget("spacer", document);
                    if (this._spacer != null || (!this._spacer && this.findSpecialWidgets(spacer.id, "spacer"))) {
                        spacer.setAttribute("label", "Интервал");
                        fragment.appendChild(gCustomizeMode.wrapToolbarItem(spacer, "palette"));
                    }
                    this._spacer = spacer.id;
                }
                if (!this._separator || this.findSpecialWidgets(this._separator, "separator")) {
                    var separator = this.Customizable.createSpecialWidget("separator", document);
                    if (this._separator != null || (!this._separator && this.findSpecialWidgets(separator.id, "separator"))) {
                        separator.setAttribute("label", "Разделитель");
                        fragment.appendChild(gCustomizeMode.wrapToolbarItem(separator, "palette"));
                    }
                    this._separator = separator.id;
                }
                gCustomizeMode.visiblePalette.appendChild(fragment);
            } catch (e) {}
        },
        findSpecialWidgets: function(eltid, string) {
            if (!eltid)
                return false;
            try {
                if (!gCustomizeMode.visiblePalette.querySelector("toolbar" + string + "[id^='" + eltid.split(string)[0] + string + "']"))
                    return true;
            } catch (e) {}
            return false;
        }
    },
    autohidesidebar: {
        sidebar: null,
        constructor: function() {
            var sidebar = this.sidebar = document.querySelector("#sidebar-box");
            if(!sidebar)
                return;
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.addEventListener(type, this, false);
            });
            ucf_custom_script_win.unloadlisteners.push("autohidesidebar");
        },
        destructor: function() {
            var sidebar = this.sidebar;
            ["dragenter", "drop", "dragexit"].forEach((type) => {
                sidebar.removeEventListener(type, this, false);
            });
        },
        handleEvent: function(event) {
            this[event.type](event);
        },
        dragenter: function() {
            if (!this.sidebar.hasAttribute("sidebardrag"))
            this.sidebar.setAttribute("sidebardrag", "true");
        },
        drop: function() {
            if (this.sidebar.hasAttribute("sidebardrag"))
            this.sidebar.removeAttribute("sidebardrag");
        },
        dragexit: function(event) {
            var sidebar = this.sidebar;
            var boxObj = sidebar.getBoundingClientRect(), boxScrn = !sidebar.boxObject ? sidebar : sidebar.boxObject;
            if ((!event.relatedTarget || event.screenY <= (boxScrn.screenY + 5) || event.screenY  >= (boxScrn.screenY + boxObj.height - 5)
                || event.screenX <= (boxScrn.screenX + 5) || event.screenX >= (boxScrn.screenX + boxObj.width - 5))
                && sidebar.hasAttribute("sidebardrag"))
                sidebar.removeAttribute("sidebardrag");
        }
    }
};

if (window.document.readyState != "complete") {
    window.addEventListener("load", function load() {
        window.removeEventListener("load", load, false);
        ucf_custom_script_win.load();
    }, false);
} else
    ucf_custom_script_win.load();

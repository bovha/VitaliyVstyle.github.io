// Этот скрипт можно использовать для создания кнопок с помощью CustomizableUI.createWidget

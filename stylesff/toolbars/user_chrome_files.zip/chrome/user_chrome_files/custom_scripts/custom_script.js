// Этот скрипт можно использовать для создания кнопок с помощью CustomizableUI.createWidget

// var {classes: Cc, interfaces: Ci, utils: Cu} = Components;
// var {console} = Cu.import("resource://gre/modules/Console.jsm", {});

// Не редактировать!
var {classes: Cc, interfaces: Ci, utils: Cu} = Components;
var PREF_BRANCH = "extensions.user_chrome_files.";
var Services = Cu.import("resource://gre/modules/Services.jsm", {}).Services;
var branch, Prefs;
var user_chrome = {
    options: {
        t_enable: true,
        b_enable: true,
        v_enable: true,
        t_collapsed: false,
        b_collapsed: false,
        v_collapsed: false,
        v_bar_start: true,
        v_autohide: false,
        v_fullscreen: true,
        v_showdelay: 300,
        v_hidedelay: 2000
    },
    initialized: false,
    winBrowser: null,
    vertical_top_bottom_bar_enable: true,
    custom_styles: false,
    custom_scripts: false,
    get styleURI() {
        delete this.styleURI;
        return this.styleURI = Services.io.newURI("chrome://user_chrome_files/content/js/vertical_top_bottom_bar.css", null, null);
    },
    get _loadIntoWindow() {
        delete this._loadIntoWindow;
        this.init();
        return this._loadIntoWindow = function(win, href) {
            var loader = Services.scriptloader;
            try {
                var utils = ("windowUtils" in win && win.windowUtils instanceof Ci.nsIDOMWindowUtils) ? win.windowUtils : win.QueryInterface(Ci.nsIInterfaceRequestor).getInterface(Ci.nsIDOMWindowUtils);
                utils.loadSheet(this.styleURI, utils.USER_SHEET);
            } catch(e) {
                Cu.reportError(e);
            }
            if (this.vertical_top_bottom_bar_enable) {
                try {
                    var options = this.options;
                    if (options.t_enable)
                        options.t_collapsed = Prefs.getBoolPref("top_collapsed");
                    if (options.b_enable)
                        options.b_collapsed = Prefs.getBoolPref("bottom_collapsed");
                    if (options.v_enable)
                        options.v_collapsed = Prefs.getBoolPref("vertical_collapsed");
                    loader.loadSubScript("chrome://user_chrome_files/content/js/vertical_top_bottom_bar.js", win, "UTF-8");
                    win.vertical_top_bottom_bar.options = options;
                    win.vertical_top_bottom_bar.constructor();
                } catch(e) {
                    Cu.reportError(e);
                }
            }
            if (this.custom_scripts) {
                try {
                    loader.loadSubScript("chrome://user_chrome_files/content/custom_scripts/custom_script_win.js", win, "UTF-8");
                } catch(e) {
                    Cu.reportError(e);
                }
            }
        };
    },
    loadIntoWindow: function(win, href) {
        if (href == "chrome://browser/content/browser.xul") {
            this.winBrowser = win;
            this._loadIntoWindow(win, href);
        }
    },
    loadPrefsStyle: function() {
        try {
            branch = Services.prefs.getDefaultBranch(PREF_BRANCH);
            Prefs = Services.prefs.getBranch(PREF_BRANCH);
            branch.setBoolPref("vertical_top_bottom_bar_enable", true);
            branch.setBoolPref("vertical_enable", true);
            branch.setBoolPref("top_enable", true);
            branch.setBoolPref("bottom_enable", true);
            branch.setBoolPref("vertical_collapsed", false);
            branch.setBoolPref("vertical_bar_start", true);
            branch.setBoolPref("vertical_autohide", false);
            branch.setBoolPref("vertical_fullscreen", true);
            branch.setIntPref("vertical_showdelay", 300);
            branch.setIntPref("vertical_hidedelay", 2000);
            branch.setBoolPref("top_collapsed", false);
            branch.setBoolPref("bottom_collapsed", false);
            branch.setBoolPref("custom_styles", false);
            branch.setBoolPref("custom_scripts", false);
            this.vertical_top_bottom_bar_enable = Prefs.getBoolPref("vertical_top_bottom_bar_enable");
            this.custom_styles = Prefs.getBoolPref("custom_styles");
            this.custom_scripts = Prefs.getBoolPref("custom_scripts");
        } catch(e) {
            Cu.reportError(e);
        }
        if (this.custom_styles) {
            try {
                var styleSS = Cc["@mozilla.org/content/style-sheet-service;1"].getService(Ci.nsIStyleSheetService);
                var styleURI = Services.io.newURI("chrome://user_chrome_files/content/user_chrome.css", null, null);
                if (!styleSS.sheetRegistered(styleURI, styleSS.AGENT_SHEET))
                    styleSS.loadAndRegisterSheet(styleURI, styleSS.AGENT_SHEET);
            } catch(e) {
                Cu.reportError(e);
            }
        }
    },
    restartMozilla: function(nocache = false) {
        var cancelQuit = Cc["@mozilla.org/supports-PRBool;1"].createInstance(Ci.nsISupportsPRBool);
        Services.obs.notifyObservers(cancelQuit, "quit-application-requested", "restart");
        if (cancelQuit.data)
            return false;
        if (nocache)
            Services.appinfo.invalidateCachesOnRestart();
        var restart = Services.startup;
        restart.quit(restart.eAttemptQuit | restart.eRestart);
    },
    init: function() {
        if (this.initialized) return;
        this.initialized = true;
        var CustomizableUI;
        try {
            CustomizableUI = Cu.import("resource:///modules/CustomizableUI.jsm", {}).CustomizableUI;
        } catch(e) {
            return;
        }
        try {
            CustomizableUI.createWidget({
                id: "add-open-about-config-button",
                type: "custom",
                label: "Открыть настройки",
                tooltiptext: "ЛКМ: Открыть настройки в окне\nСКМ: Открыть about:config\nПКМ: Открыть настройки во вкладке",
                onBuild: function (document) {
                    var win = document.defaultView;
                    var toolbarbutton_0 = document.createElement("toolbarbutton");
                    toolbarbutton_0.id = "add-open-about-config-button";
                    toolbarbutton_0.setAttribute("label", "Открыть настройки");
                    toolbarbutton_0.setAttribute("context", false);
                    toolbarbutton_0.setAttribute("tooltiptext", "ЛКМ: Открыть настройки в окне\nСКМ: Открыть about:config\nПКМ: Открыть настройки во вкладке");
                    toolbarbutton_0.addEventListener("click", function(event) {
                        if (event.button == 0) {
                            var prefwin = Services.wm.getMostRecentWindow("user_chrome_prefs:window");
                            if (prefwin)
                                prefwin.focus();
                            else
                                win.openDialog("chrome://user_chrome_files/content/options/user_chrome_prefs.xul", "user_chrome_prefs:window", "centerscreen,resizable,dialog=no");
                        } else if (event.button == 1) {
                            win.gBrowser.selectedTab = win.gBrowser.addTab("about:config", {
                                triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal()
                            });
                        } else if (event.button == 2) {
                            var prefsInfo = "chrome://user_chrome_files/content/options/user_chrome_prefs.xhtml";
                            if ("gInitialPages" in win && win.gInitialPages.indexOf(prefsInfo) == -1) win.gInitialPages.push(prefsInfo);
                            win.gBrowser.selectedTab = win.gBrowser.addTab(prefsInfo, {
                                triggeringPrincipal: Services.scriptSecurityManager.getSystemPrincipal()
                            });
                        }
                    }, false);
                    toolbarbutton_0.classList.add("toolbarbutton-1");
                    toolbarbutton_0.classList.add("chromeclass-toolbar-additional");
                    return toolbarbutton_0;
                }
            });
        } catch(e) {}
        if (this.vertical_top_bottom_bar_enable) {
            var options = this.options;
            var v_enable, t_enable, b_enable;
            try {
                v_enable = options.v_enable = Prefs.getBoolPref("vertical_enable");
                t_enable = options.t_enable = Prefs.getBoolPref("top_enable");
                b_enable = options.b_enable = Prefs.getBoolPref("bottom_enable");
                if (v_enable) {
                    options.v_collapsed = Prefs.getBoolPref("vertical_collapsed");
                    options.v_bar_start = Prefs.getBoolPref("vertical_bar_start");
                    options.v_autohide = Prefs.getBoolPref("vertical_autohide");
                    options.v_fullscreen = Prefs.getBoolPref("vertical_fullscreen");
                    options.v_showdelay = Prefs.getIntPref("vertical_showdelay");
                    options.v_hidedelay = Prefs.getIntPref("vertical_hidedelay");
                }
                if (t_enable)
                    options.t_collapsed = Prefs.getBoolPref("top_collapsed");
                if (b_enable)
                    options.b_collapsed = Prefs.getBoolPref("bottom_collapsed");
            } catch(e) { }
            try {
                if (v_enable) {
                    CustomizableUI.registerArea("add-additional-vertical-bar", {
                        type: CustomizableUI.TYPE_TOOLBAR,
                        defaultPlacements: ["add-view-bookmarks-sidebar-button", "add-view-history-sidebar-button", "add-additional-vertical-spring", "add-open-about-config-button"],
                        defaultCollapsed: false
                    });
                }
            } catch(e) {}
            try {
                if (t_enable) {
                    CustomizableUI.registerArea("add-additional-top-bar", {
                        type: CustomizableUI.TYPE_TOOLBAR,
                        defaultPlacements: ["add-open-directories-button", "add-additional-top-spring", "add-restart-app"],
                        defaultCollapsed: false
                    });
                }
            } catch(e) {}
            try {
                if (b_enable) {
                    CustomizableUI.registerArea("add-additional-bottom-bar", {
                        type: CustomizableUI.TYPE_TOOLBAR,
                        defaultPlacements: ["add-additional-bottom-closebutton", "add-additional-bottom-spring"],
                        defaultCollapsed: false
                    });
                }
            } catch(e) {}
            try {
                if (t_enable) {
                    CustomizableUI.createWidget({
                        id: "add-additional-top-spring",
                        type: "custom",
                        label: "Растягивающийся интервал",
                        onBuild: function(document) {
                            var toolbaritem = document.createElement("toolbaritem");
                            toolbaritem.id = "add-additional-top-spring";
                            toolbaritem.className = "add-additional-springs";
                            toolbaritem.setAttribute("label", "Растягивающийся интервал");
                            toolbaritem.setAttribute("type", "custom");
                            toolbaritem.setAttribute("flex", "1");
                            return toolbaritem;
                        }
                    });
                }
            } catch(e) {}
            try {
                if (v_enable) {
                    CustomizableUI.createWidget({
                        id: "add-additional-vertical-spring",
                        type: "custom",
                        label: "Растягивающийся интервал",
                        onBuild: function(document) {
                            var toolbaritem = document.createElement("toolbaritem");
                            toolbaritem.id = "add-additional-vertical-spring";
                            toolbaritem.className = "add-additional-springs";
                            toolbaritem.setAttribute("label", "Растягивающийся интервал");
                            toolbaritem.setAttribute("type", "custom");
                            toolbaritem.setAttribute("flex", "1");
                            return toolbaritem;
                        }
                    });
                }
            } catch(e) {}
            try {
                if (b_enable) {
                    CustomizableUI.createWidget({
                        id: "add-additional-bottom-spring",
                        type: "custom",
                        label: "Растягивающийся интервал",
                        onBuild: function(document) {
                            var toolbaritem = document.createElement("toolbaritem");
                            toolbaritem.id = "add-additional-bottom-spring";
                            toolbaritem.className = "add-additional-springs";
                            toolbaritem.setAttribute("label", "Растягивающийся интервал");
                            toolbaritem.setAttribute("type", "custom");
                            toolbaritem.setAttribute("flex", "1");
                            return toolbaritem;
                        }
                    });
                }
            } catch(e) {}
            try {
                CustomizableUI.createWidget({
                    id: "add-restart-app",
                    type: "custom",
                    label: "Перезагрузка",
                    tooltiptext: "ЛКМ: Перезапустить приложение\nСКМ: Перезапустить без дополнений\nПКМ: Отключить загрузку содержимого из кеша и перезапустить",
                    onBuild: function(document) {
                        var win = document.defaultView;
                        var toolbarbutton_0 = document.createElement("toolbarbutton");
                        toolbarbutton_0.id = "add-restart-app";
                        toolbarbutton_0.setAttribute("label", "Перезагрузка");
                        toolbarbutton_0.setAttribute("context", false);
                        toolbarbutton_0.setAttribute("tooltiptext", "ЛКМ: Перезапустить приложение\nСКМ: Перезапустить без дополнений\nПКМ: Отключить загрузку содержимого из кеша и перезапустить");
                        toolbarbutton_0.addEventListener("click", function(event) {
                            if (event.button == 0)
                                user_chrome.restartMozilla();
                            else if (event.button == 1)
                                win.safeModeRestart();
                            else if (event.button == 2) {
                                event.preventDefault();
                                event.stopPropagation();
                                user_chrome.restartMozilla(true);
                            }
                        }, false);
                        toolbarbutton_0.classList.add("toolbarbutton-1");
                        toolbarbutton_0.classList.add("chromeclass-toolbar-additional");
                        return toolbarbutton_0;
                    }
                });
            } catch(e) {}
            try {
                if (v_enable) {
                    CustomizableUI.createWidget({
                        id: "add-additional-vertical-toggle-button",
                        label: "Переключить Верт. панель",
                        tooltiptext: "Скрыть / Показать Вертикальную панель",
                        onCommand: function(event) {
                            var doc = event.target.ownerDocument;
                            var win = doc.defaultView;
                            var bar = doc.querySelector("#add-additional-vertical-bar");
                            win.setToolbarVisibility(bar, bar.collapsed);
                        }
                    });
                }
            } catch(e) {}
            try {
                if (t_enable) {
                    CustomizableUI.createWidget({
                        id: "add-additional-top-toggle-button",
                        label: "Переключить Доп. панель",
                        tooltiptext: "Скрыть / Показать Дополнительную панель",
                        onCommand: function(event) {
                            var doc = event.target.ownerDocument;
                            var win = doc.defaultView;
                            var bar = doc.querySelector("#add-additional-top-bar");
                            win.setToolbarVisibility(bar, bar.collapsed);
                        }
                    });
                }
            } catch(e) {}
            try {
                if (b_enable) {
                    CustomizableUI.createWidget({
                        id: "add-additional-bottom-toggle-button",
                        label: "Переключить Ниж. панель",
                        tooltiptext: "Скрыть / Показать Нижнюю панель",
                        onCommand: function(event) {
                            var doc = event.target.ownerDocument;
                            var win = doc.defaultView;
                            var bar = doc.querySelector("#add-additional-bottom-bar");
                            win.setToolbarVisibility(bar, bar.collapsed);
                        }
                    });
                }
            } catch(e) {}
            try {
                CustomizableUI.createWidget({
                    id: "add-view-history-sidebar-button",
                    label: "История",
                    tooltiptext: "Показать / Скрыть Историю",
                    onCommand: function(event) {
                        var win = event.target.ownerDocument.defaultView;
                        if ("SidebarUI" in win)
                            win.SidebarUI.toggle("viewHistorySidebar");
                        else if ("toggleSidebar" in win)
                            win.toggleSidebar("viewHistorySidebar");
                    }
                });
            } catch(e) {}
            try {
                CustomizableUI.createWidget({
                    id: "add-view-bookmarks-sidebar-button",
                    label: "Закладки",
                    tooltiptext: "Показать / Скрыть Закладки",
                    onCommand: function(event) {
                        var win = event.target.ownerDocument.defaultView;
                        if ("SidebarUI" in win)
                            win.SidebarUI.toggle("viewBookmarksSidebar");
                        else if ("toggleSidebar" in win)
                            win.toggleSidebar("viewBookmarksSidebar");
                    }
                });
            } catch(e) {}
            try {
                CustomizableUI.createWidget({
                    id: "add-open-directories-button",
                    type: "custom",
                    label: "Открыть папку",
                    tooltiptext: "ЛКМ: Папка user_chrome_files\nСКМ: Папка профиля\nПКМ: Папка установки",
                    onBuild: function (document) {
                        var toolbarbutton_0 = document.createElement("toolbarbutton");
                        toolbarbutton_0.id = "add-open-directories-button";
                        toolbarbutton_0.setAttribute("label", "Открыть папку");
                        toolbarbutton_0.setAttribute("context", false);
                        toolbarbutton_0.setAttribute("tooltiptext", "ЛКМ: Папка user_chrome_files\nСКМ: Папка профиля\nПКМ: Папка установки");
                        toolbarbutton_0.addEventListener("click", function(event) {
                            var dirs;
                            if (event.button == 0) {
                                dirs = Services.dirsvc.get("ProfD", Ci.nsIFile);
                                dirs.append("user_chrome_files");
                                if (dirs.exists()) dirs.launch();
                            } else if (event.button == 1) {
                                dirs = Services.dirsvc.get("ProfD", Ci.nsIFile);
                                if (dirs.exists()) dirs.launch();
                            } else if (event.button == 2) {
                                dirs = Services.dirsvc.get("GreD", Ci.nsIFile);
                                dirs.launch();
                            }
                        }, false);
                        toolbarbutton_0.classList.add("toolbarbutton-1");
                        toolbarbutton_0.classList.add("chromeclass-toolbar-additional");
                        return toolbarbutton_0;
                    }
                });
            } catch(e) {}
        }
        if (this.custom_scripts) {
            try {
                var scope = {
                    Services: Services,
                    CustomizableUI: CustomizableUI,
                    window: this.winBrowser
                };
                Services.scriptloader.loadSubScript("chrome://user_chrome_files/content/custom_scripts/custom_script.js", scope, "UTF-8");
            } catch(e) {
                Cu.reportError(e);
            }
        }
    }
};
user_chrome.loadPrefsStyle();

// Не редактировать!
var {classes: Cc, interfaces: Ci, utils: Cu} = Components;
var Services = Cu.import("resource://gre/modules/Services.jsm", {}).Services;
var controlArray = ["extensions.user_chrome_files.vertical_top_bottom_bar_enable", "extensions.user_chrome_files.vertical_enable"];
window.addEventListener("load", function onLoad() {
  window.removeEventListener("load", onLoad, true);

  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    Services.prefs.addObserver(pref, FillForm, false);
    i.addEventListener("change", SaveForm, false);
  }

  document.querySelector("#restore").onclick = RestoreDefaults;
  document.querySelector("#restart").onclick = Restart;

  FillForm();

}, true);

window.addEventListener("unload", function onUnload() {
  window.removeEventListener("unload", onUnload, true);
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    i.removeEventListener("change", SaveForm, false);
    Services.prefs.removeObserver(pref, FillForm, false);
  }
}, true);

function FillForm() {
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    var val = GetPref(pref);
    if (i.type == "checkbox") {
      i.checked = val;
      if (controlArray.indexOf(pref) != -1)
          i.parentNode.nextSibling.disabled = !val;
    } else {
      i.value = val;
    }
  }
}

function SaveForm(e) {
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    if (i.type == "checkbox") {
      SetPref(pref, i.checked);
    } else {
      SetPref(pref, i.value);
    }
  }
}

function GetPref(name) {
  var type = Services.prefs.getPrefType(name);
  switch (type) {
    case Services.prefs.PREF_STRING:
      return Services.prefs.getCharPref(name);
    case Services.prefs.PREF_INT:
      return Services.prefs.getIntPref(name);
    case Services.prefs.PREF_BOOL:
      return Services.prefs.getBoolPref(name);
  }
}

function SetPref(name, value) {
  var type = Services.prefs.getPrefType(name);
  switch (type) {
    case Services.prefs.PREF_STRING:
      return Services.prefs.setCharPref(name, value);
    case Services.prefs.PREF_INT:
      return Services.prefs.setIntPref(name, value);
    case Services.prefs.PREF_BOOL:
      return Services.prefs.setBoolPref(name, value);
  }
}

function RestoreDefaults() {
  var inputs = document.querySelectorAll("[data-pref]");
  for (var i of inputs) {
    var pref = i.dataset.pref;
    Services.prefs.clearUserPref(pref);
  }
}

function Restart() {
  var cancelQuit = Cc["@mozilla.org/supports-PRBool;1"].createInstance(Ci.nsISupportsPRBool);
  Services.obs.notifyObservers(cancelQuit, "quit-application-requested", "restart");
  if (cancelQuit.data)
    return false;
  var restart = Services.startup;
  restart.quit(restart.eAttemptQuit | restart.eRestart);
}

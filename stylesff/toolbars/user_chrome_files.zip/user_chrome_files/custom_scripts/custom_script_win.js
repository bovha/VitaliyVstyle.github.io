// Этот скрипт работает в главном окне браузера если включено в настройках
var {classes: Cc, interfaces: Ci, utils: Cu} = Components;

// Вы должны использовать событие "load" если хотите дождаться загрузки всех ресурсов
window.addEventListener("load", function load() {
    window.removeEventListener("load", load, false);
    // myExtension.init();
}, false);
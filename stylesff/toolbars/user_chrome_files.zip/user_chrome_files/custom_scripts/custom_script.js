// Этот скрипт работает в основном потоке если включено в настройках
// его можно использовать для создания кнопок с помощью CustomizableUI.createWidget
var {classes: Cc, interfaces: Ci, utils: Cu} = Components;
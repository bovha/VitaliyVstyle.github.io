var Cc = Components.classes;
var Ci = Components.interfaces;
var addAdditionalBottomBar = {
	toggleAdditionalBottomBar: function() {
		let bar = document.getElementById("add-additional-bottom-bar");
		setToolbarVisibility(bar, bar.collapsed);
	},
	restart: function() {
        var canceled = Cc["@mozilla.org/supports-PRBool;1"].createInstance(Ci.nsISupportsPRBool);
        var observerSvc = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);
        observerSvc.notifyObservers(canceled, "quit-application-requested", "restart");
        if (canceled.data)
            return false;
        const appStartup = Cc["@mozilla.org/toolkit/app-startup;1"].getService(Ci.nsIAppStartup);
        appStartup.quit(Ci.nsIAppStartup.eAttemptQuit | Ci.nsIAppStartup.eRestart);
	}
}